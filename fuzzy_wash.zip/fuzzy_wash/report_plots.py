"""Creates the report figures: membership functions, control surface, crisp-vs-fuzzy.  pip install matplotlib numpy"""
import numpy as np, matplotlib.pyplot as plt
import fuzzy_engine as fz
c = fz.curves()
fig, ax = plt.subplots(1, 2, figsize=(11, 3.6))
for k, v in c["in"].items(): ax[0].plot(c["x"], v, label=k)
for k, v in c["time"].items(): ax[1].plot(c["tx"], v, label=k)
ax[0].set_title("Dirtiness / Grease / Load"); ax[1].set_title("Wash time (min)")
for a in ax: a.legend(); a.set_ylabel("membership")
fig.tight_layout(); fig.savefig("fig_membership.png", dpi=160)
s = fz.surface(50, 5); ax_ = np.array(s["axis"]); X, Y = np.meshgrid(ax_, ax_)
f3 = plt.figure(figsize=(6, 4.6)); a3 = f3.add_subplot(projection="3d")
a3.plot_surface(X, Y, np.array(s["z"]).T, cmap="viridis"); a3.set_xlabel("Dirtiness"); a3.set_ylabel("Grease"); a3.set_zlabel("Time")
f3.savefig("fig_surface.png", dpi=160)
b = fz.boundary(50, 50); f4, a4 = plt.subplots(figsize=(6, 3.6))
a4.step(b["x"], b["crisp"], label="Crisp", where="post"); a4.plot(b["x"], b["fuzzy"], label="Fuzzy")
a4.set_xlabel("Dirtiness (Grease=50)"); a4.set_ylabel("Wash time"); a4.legend(); f4.tight_layout(); f4.savefig("fig_compare.png", dpi=160)
print("Saved fig_membership.png, fig_surface.png, fig_compare.png")
