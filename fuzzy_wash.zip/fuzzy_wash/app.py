"""Run:  python app.py   then open http://localhost:8000   (standard library only)."""
import json, os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
import fuzzy_engine as fz, expert_system as ex

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
TYPES = {".html": "text/html", ".css": "text/css", ".js": "text/javascript"}

def integrate(inp, facts):
    """Expert system sits above the fuzzy controller: critical fault stops, minor fault shortens the wash."""
    f, d = fz.run(*inp), ex.diagnose(facts)
    t, w, note = f["time"], f["water"], "Fuzzy controller is in charge."
    if d["action"] == "STOP":
        t, w, note = 0, 0, "Critical fault found. Wash stopped."
    elif d["action"] == "ADAPT":
        t, note = t * 0.75, "Minor fault found. Safe cycle: wash time cut by 25%."
    return {"fuzzy": f, "expert": d, "final": {"action": d["action"], "time": t, "water": w, "note": note}}

class H(BaseHTTPRequestHandler):
    def reply(self, body, ctype="application/json", code=200):
        b = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code); self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        u = urlparse(self.path); q = {k: float(v[0]) for k, v in parse_qs(u.query).items()}
        if u.path == "/api/curves": return self.reply(fz.curves())
        if u.path == "/api/surface": return self.reply(fz.surface(q.get("load", 50)))
        if u.path == "/api/boundary": return self.reply(fz.boundary(q.get("grease", 50), q.get("load", 50)))
        if u.path == "/api/facts": return self.reply([{"id": a, "label": b, "group": c} for a, b, c in ex.FACTS])
        p = os.path.normpath(os.path.join(ROOT, "index.html" if u.path == "/" else u.path.lstrip("/")))
        if p.startswith(ROOT) and os.path.isfile(p):
            return self.reply(open(p, "rb").read(), TYPES.get(os.path.splitext(p)[1], "text/plain"))
        self.reply({"error": "not found"}, code=404)
    def do_POST(self):
        if self.path != "/api/run": return self.reply({"error": "not found"}, code=404)
        b = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        self.reply(integrate((b["dirt"], b["grease"], b["load"]), b.get("facts", [])))
    def log_message(self, *a): pass

if __name__ == "__main__":
    print("Fuzzy Wash running at http://localhost:8000"); ThreadingHTTPServer(("", 8000), H).serve_forever()
