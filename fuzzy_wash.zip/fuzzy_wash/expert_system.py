"""Forward-chaining fault-diagnosis expert system with certainty factors and an explanation facility."""
FACTS = [  # (id, label, group)
 ("no_water", "No water enters the drum", "Water"), ("tap_on", "Tap is open", "Water"),
 ("err_E10", "Display shows E10", "Error code"), ("err_E21", "Display shows E21", "Error code"),
 ("water_stays", "Water stays in the drum", "Draining"), ("slow_drain", "Draining is slow", "Draining"),
 ("pump_hums", "Drain pump hums", "Draining"), ("pump_silent", "Drain pump is silent", "Draining"),
 ("no_spin", "Drum does not spin", "Spinning"), ("belt_loose", "Belt feels loose", "Spinning"),
 ("motor_hum", "Motor hums but drum is still", "Spinning"),
 ("door_open", "Door will not close", "Door"), ("door_latch_broken", "Latch feels broken", "Door"),
 ("excess_vibration", "Heavy vibration", "Noise and leaks"), ("unbalanced_load", "Clothes bunched on one side", "Noise and leaks"),
 ("leak_bottom", "Water leaks underneath", "Noise and leaks"), ("hose_loose", "A hose is loose", "Noise and leaks"),
 ("foam_excess", "Too much foam", "Other"), ("overflow", "Soapy water overflows", "Other"),
 ("not_heating", "Water stays cold", "Other"), ("bad_smell", "Drum smells musty", "Other"),
 ("cycles_over_500", "Over 500 cycles run", "Usage history"), ("drain_time_up", "Drain time rising lately", "Usage history"),
]
# (id, conditions ('!x' = x absent), conclusion, certainty, severity, plain-language advice)
RULES = [
 ("R1",  ["no_water", "tap_on"], "inlet_blocked", .85, "critical", "Inlet valve or filter is blocked. Clean the inlet filter."),
 ("R2",  ["err_E10"], "inlet_blocked", .90, "critical", "Inlet valve or filter is blocked. Clean the inlet filter."),
 ("R3",  ["no_water", "!tap_on"], "tap_closed", .90, "minor", "The tap is closed. Open it and restart."),
 ("R4",  ["water_stays", "pump_hums"], "pump_clogged", .80, "critical", "Drain pump or hose is clogged. Clear the pump filter."),
 ("R5",  ["water_stays", "pump_silent"], "pump_failure", .75, "critical", "Drain pump has failed. Call a technician."),
 ("R6",  ["err_E21"], "drain_fault", 1.0, "", ""),
 ("R7",  ["drain_fault", "pump_hums"], "pump_clogged", .90, "critical", "Drain pump or hose is clogged. Clear the pump filter."),
 ("R8",  ["slow_drain", "drain_time_up", "cycles_over_500"], "filter_clog_soon", .80, "minor", "Predictive warning: clean the pump filter within a few washes."),
 ("R9",  ["no_spin", "belt_loose"], "belt_worn", .85, "critical", "Drive belt is worn. Replace the belt."),
 ("R10", ["no_spin", "motor_hum", "!belt_loose"], "motor_capacitor", .70, "critical", "Motor start capacitor is likely weak. Call a technician."),
 ("R11", ["no_spin", "water_stays"], "drain_fault", .90, "", ""),
 ("R12", ["door_open"], "door_not_latched", .90, "critical", "Door is not latched. Check for trapped clothes."),
 ("R13", ["door_latch_broken", "!door_open"], "door_lock_failure", .85, "critical", "Door lock has failed. Replace the lock."),
 ("R14", ["excess_vibration", "unbalanced_load"], "rebalance_load", .90, "minor", "Redistribute the clothes and run again."),
 ("R15", ["excess_vibration", "!unbalanced_load"], "levelling_issue", .70, "minor", "Level the machine. Check the shock absorbers."),
 ("R16", ["leak_bottom", "hose_loose"], "hose_clamp_loose", .85, "critical", "Tighten the hose clamp."),
 ("R17", ["leak_bottom", "!hose_loose"], "seal_or_pump_leak", .60, "critical", "Check the door seal and pump housing for cracks."),
 ("R18", ["foam_excess", "overflow"], "detergent_overdose", .90, "minor", "Too much detergent. Use less and run a rinse."),
 ("R19", ["not_heating"], "heater_fault", .75, "minor", "Heater element may have failed. Cold washes still work."),
 ("R20", ["bad_smell"], "drum_biofilm", .80, "minor", "Run a hot tub-clean cycle and leave the door open."),
]
INFO = {r[2]: (r[4], r[5]) for r in RULES if r[4]}

def diagnose(facts):
    wm = {f: 1.0 for f in facts}; fired, trace, changed = set(), [], True
    while changed:                                   # forward chaining until no rule can fire
        changed = False
        for rid, conds, concl, cf, sev, _ in RULES:
            if rid in fired: continue
            pos = [c for c in conds if not c.startswith("!")]
            if all(c in wm for c in pos) and all(c[1:] not in wm for c in conds if c.startswith("!")):
                c = cf * min(wm[p] for p in pos)
                old = wm.get(concl); wm[concl] = c if old is None else 1 - (1 - old) * (1 - c)
                fired.add(rid); changed = True
                trace.append({"rule": rid, "because": conds, "concl": concl, "cf": round(c, 2)})
    diags = [{"id": k, "cf": round(v, 2), "sev": INFO[k][0], "advice": INFO[k][1]}
             for k, v in wm.items() if k in INFO]
    diags.sort(key=lambda d: -d["cf"])
    action = "STOP" if any(d["sev"] == "critical" for d in diags) else "ADAPT" if diags else "NORMAL"
    return {"diagnoses": diags, "trace": trace, "action": action}
