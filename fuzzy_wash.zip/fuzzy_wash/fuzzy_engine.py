"""Pure-Python Mamdani fuzzy controller (no external libraries).
Inputs: Dirtiness, Grease, Load (0-100). Outputs: Wash time (0-60 min), Water level (0-100 %)."""
LEVELS = ["Low", "Medium", "High"]
MFS = {
    "in":   {"Low": (0, 0, 50), "Medium": (25, 50, 75), "High": (50, 100, 100)},
    "time": {"Short": (0, 0, 30), "Medium": (15, 30, 45), "Long": (30, 60, 60)},
}
# 3x3 rule base: Dirt (row) x Grease (col) -> Wash time
TIME_RULES = {"Low":    {"Low": "Short",  "Medium": "Medium", "High": "Medium"},
              "Medium": {"Low": "Short",  "Medium": "Medium", "High": "Long"},
              "High":   {"Low": "Medium", "Medium": "Long",   "High": "Long"}}
# Extra feature: Load (row) x Dirt (col) -> Water level
WATER_RULES = {"Low":    {"Low": "Low",    "Medium": "Low",    "High": "Medium"},
               "Medium": {"Low": "Low",    "Medium": "Medium", "High": "High"},
               "High":   {"Low": "Medium", "Medium": "High",   "High": "High"}}
CRISP_TIME = {"Short": 15, "Medium": 30, "Long": 50}      # fixed programmes
CRISP_WATER = {"Low": 30, "Medium": 55, "High": 80}
BASE = {"time": 45, "litres": 60, "kwh": 0.675}          # fixed 'Normal' programme (assumed)

def tri(x, a, b, c):
    if x < a or x > c: return 0.0
    if x == b: return 1.0
    return (x - a) / (b - a) if x < b else (c - x) / (c - b)

def fuzzify(x, mfs): return {k: tri(x, *v) for k, v in mfs.items()}

def centroid(strengths, mfs, hi, step=1.0):
    xs, agg, num, den, u = [], [], 0.0, 0.0, 0.0
    while u <= hi + 1e-9:
        mu = max(min(s, tri(u, *mfs[k])) for k, s in strengths.items())   # clip + aggregate (max)
        xs.append(u); agg.append(mu); num += u * mu; den += mu; u += step
    return (num / den if den else hi / 2), xs, agg, num, den

def crisp_label(x): return "Low" if x < 33 else "Medium" if x < 67 else "High"

def crisp_controller(dirt, grease, load):
    t = CRISP_TIME[TIME_RULES[crisp_label(dirt)][crisp_label(grease)]]
    w = CRISP_WATER[WATER_RULES[crisp_label(load)][crisp_label(dirt)]]
    return t, w

def usage(time, water):
    litres, kwh = 20 + 0.6 * water, 0.9 * time / 60
    return {"litres": litres, "kwh": kwh,
            "water_saved": 100 * (BASE["litres"] - litres) / BASE["litres"],
            "energy_saved": 100 * (BASE["kwh"] - kwh) / BASE["kwh"]}

def run(dirt, grease, load):
    fd, fg, fl = (fuzzify(v, MFS["in"]) for v in (dirt, grease, load))
    ts = {k: 0.0 for k in MFS["time"]}; ws = {k: 0.0 for k in LEVELS}; fired = []
    for d in LEVELS:
        for g in LEVELS:
            s, o = min(fd[d], fg[g]), TIME_RULES[d][g]; ts[o] = max(ts[o], s)
            fired.append({"text": f"IF Dirt is {d} AND Grease is {g} THEN Wash time is {o}", "s": s})
    for l in LEVELS:
        for d in LEVELS:
            s, o = min(fl[l], fd[d]), WATER_RULES[l][d]; ws[o] = max(ws[o], s)
            fired.append({"text": f"IF Load is {l} AND Dirt is {d} THEN Water level is {o}", "s": s})
    time, tx, tagg, num, den = centroid(ts, MFS["time"], 60)
    water = centroid(ws, MFS["in"], 100)[0]
    ct, cw = crisp_controller(dirt, grease, load)
    return {"fuzz": {"Dirtiness": fd, "Grease": fg, "Load": fl},
            "fired": sorted([f for f in fired if f["s"] > 0], key=lambda f: -f["s"]),
            "time": time, "water": water, "tx": tx, "tagg": tagg, "num": num, "den": den,
            "crisp_time": ct, "crisp_water": cw, "usage": usage(time, water)}

def surface(load=50, step=5):
    ax = list(range(0, 101, step))
    return {"axis": ax, "z": [[run(d, g, load)["time"] for g in ax] for d in ax]}

def boundary(grease=50, load=50):
    xs = list(range(0, 101))
    return {"x": xs, "fuzzy": [run(d, grease, load)["time"] for d in xs],
            "crisp": [crisp_controller(d, grease, load)[0] for d in xs]}

def curves():
    gx, tx = list(range(0, 101)), list(range(0, 61))
    return {"x": gx, "in": {k: [tri(x, *v) for x in gx] for k, v in MFS["in"].items()},
            "tx": tx, "time": {k: [tri(x, *v) for x in tx] for k, v in MFS["time"].items()}}

if __name__ == "__main__":
    r = run(60, 70, 50)
    print("Dirt=60 Grease=70 Load=50 -> fuzzy time %.2f min, crisp %d min" % (r["time"], r["crisp_time"]))
