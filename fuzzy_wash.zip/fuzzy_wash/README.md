# Fuzzy Wash (Case Study 5)
Run: `python app.py` then open http://localhost:8000  (Python 3.8+, no packages needed)
Report figures: `pip install matplotlib numpy` then `python report_plots.py`
Files: fuzzy_engine.py (Mamdani, 9+9 rules) | expert_system.py (20 rules, forward chaining, CF, explanation) | app.py (server + integration) | static/ (UI)
